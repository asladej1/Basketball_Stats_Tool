import random
from constants import PLAYERS
from constants import TEAMS

GREETING = 'BASKETBALL TEAM STATS TOOL\n'

players = PLAYERS.copy()
teams = TEAMS.copy()

print(GREETING.upper())


print('-----MENU-----\n')


# Split players into exp and nexp
def split_into_exp_nexp_players(players_list):
    exp_players = []
    nexp_players = []
    for player in players_list:
        if player['experience'] == 'YES':
            exp_players.append(player)
        else:
            nexp_players.append(player)
            
    return exp_players, nexp_players


# Function that will split a list into equal n lists
# credit: https://stackoverflow.com/questions/3352737/how-to-randomly-partition-a-list-into-n-nearly-equal-parts
def partition (list_in, n):
    random.shuffle(list_in)
    return [list_in[i::n] for i in range(n)]


# Using that function above, create the equal splits into n teams
def split_into_teams(teams, exp_players, nexp_players):
    exp_split = partition(exp_players, len(teams))
    nexp_split = partition(nexp_players, len(teams))
        
    return exp_split, nexp_split


exp_players, nexp_players = split_into_exp_nexp_players(players)
exp_players, nexp_players = split_into_teams(teams, exp_players, nexp_players)


# Put each of those partitioned players into teams
team_rosters = {}
for idx, team in enumerate(teams):
    comb_players = exp_players[idx] + nexp_players[idx]
    team_rosters[team] = comb_players
    

for team, roster in team_rosters.items():
    print('%s:' %team)
    for each_player in roster:
        print(each_player['name'])
        
    print('\n')